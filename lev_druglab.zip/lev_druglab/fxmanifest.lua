fx_version 'cerulean'
games {'gta5'}

this_is_a_map 'yes'